export default function MyPage() {
    return(
        <div className="MyPage">
            im mypage section
        </div>
    )
};
