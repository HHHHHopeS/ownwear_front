import "./Main.scss"

export default function Main() {
    return(
        <div className="Main">

            <div className="side-section">
            im main page
            </div>
            <div className="main-section">

            </div>
        </div>
    )
};
