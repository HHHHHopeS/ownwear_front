import "./Profile.scss"

export default function Profile() {
    return(
        <div className="Detail">
                Im profile Page
            </div>
            )
};
