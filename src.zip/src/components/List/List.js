import "./List.scss"

export default function List() {
    return(
        <div className="List">
                Im list Page
            </div>
            )
};
