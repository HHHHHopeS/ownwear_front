import "./Ranking.scss"

export default function Ranking() {
    return(
        <div className="Detail">
                Im ranking Page
            </div>
            )
};
