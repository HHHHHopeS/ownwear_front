import './Detail.scss'

export default function Detail() {
    return(
    <div className="Detail">
            Im detail Page
        </div>
        )
};
