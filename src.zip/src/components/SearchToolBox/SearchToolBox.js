import "./SearchToolBox.scss"
export default function SearchToolBox() {
    return(
        <div className="SearchToolBox">
            <h1>test</h1>
        </div>
    )
    
};
