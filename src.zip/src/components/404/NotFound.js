export default function NotFound() {
    return(
        <div className="NotFound">
            404!!!!
        </div>
    )
    
};
