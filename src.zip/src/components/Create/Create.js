import "./Create.scss"

export default function Create() {
    return(
        <div className="Create">
            Im create Page
        </div>
    )
};
